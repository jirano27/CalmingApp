//
//  calmingApp.swift
//  calming
//

import SwiftUI

@main
struct calmingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
